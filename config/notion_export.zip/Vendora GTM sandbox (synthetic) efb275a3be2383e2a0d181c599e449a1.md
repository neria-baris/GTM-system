# Vendora GTM sandbox (synthetic)

**This workspace is synthetic.** It shows the structure of a typical B2B team's Notion and CRM. Every company, contact, deal, note and team member in it is invented; any resemblance to real organisations or people is coincidental.

**"Today" in this dataset is Sunday 13 September 2026.**

## What is here

- **Meeting notes** - the team's meeting notes database, as we actually use it.
- **GTM target (draft)** - the number the board cares about.
- **CRM** (separate base) - Companies, Contacts, Deals, Activities.

[GTM target (draft)](Vendora%20GTM%20sandbox%20(synthetic)/GTM%20target%20(draft)%20db0275a3be2383c1a318016405f7ee00.md)

[Meeting notes](Vendora%20GTM%20sandbox%20(synthetic)/Meeting%20notes%20dd1275a3be238220b4aa81fa29081970.csv)
