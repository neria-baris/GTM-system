# GTM target (draft)

## Target

- **$5.0M of new annual contract value (ACV) signed in commercial deployments by 31 March 2027** (counted from 1 Jan 2026). Pilot fees don't count.
- We want to know every week whether we're on track.

## Rough pricing we quote

- Grocery retail: pilot $150k-$320k; rollout typically 3-6x the pilot per year
- Wholesale distribution: pilot $100k-$240k; rollout typically 3-6x the pilot per year

## FX for planning

- 1 GBP = $1.32
- 1 EUR = $1.12
- 1 JPY = $0.0067