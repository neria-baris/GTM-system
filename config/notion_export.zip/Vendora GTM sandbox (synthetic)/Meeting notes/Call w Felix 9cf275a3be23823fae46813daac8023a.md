# Call w/ Felix

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: March 26, 2026
Last edited by: טל אדלר
Meeting type: Scoping

# Agenda

# Notes

- Data: daily stock-level feeds
- Pilot scope: 3-warehouse cluster
- multi-warehouse allocation conflicts
- Budget: pilot ~€185k, rollout maybe €580k/yr if it works