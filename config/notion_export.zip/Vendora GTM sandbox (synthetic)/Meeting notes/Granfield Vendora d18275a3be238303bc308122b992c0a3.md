# Granfield <> Vendora

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: May 22, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Forecast model fit on historic data, held-out error within tolerance
- wk 12. next: second scenario