# Mosel Fracht <> Vendora

Attendees: Owen Marsh
Created by: טל אדלר
Date: March 14, 2026
Last edited by: טל אדלר
Meeting type: Follow-up

# Agenda

- Intro Vendora
- Their pain points

# Notes

- carrying costs up sharply YoY - Felix says this costs them real money
- Setup: home-grown scripts on stock reports
- multi-warehouse allocation conflicts
- Keen - wants a deep dive with their engineers
- Next: send one-pager, book scoping w/ Felix's team