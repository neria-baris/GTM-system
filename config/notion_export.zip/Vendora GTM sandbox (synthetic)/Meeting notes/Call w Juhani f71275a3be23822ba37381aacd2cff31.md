# Call w/ Juhani

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: May 7, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Blocked ~2 weeks on data export, unblocked now
- wk 16. next: interim results to their VP