# Quorra Supply

Attendees: Owen Marsh
Created by: טל אדלר
Date: April 11, 2026
Last edited by: טל אדלר
Meeting type: Scoping

# Agenda

# Notes

- Integration: two-vendor WMS + vendor planning suite
- Pilot scope: shadow-mode planning on 500 SKUs
- fill-rate impact must be ~zero