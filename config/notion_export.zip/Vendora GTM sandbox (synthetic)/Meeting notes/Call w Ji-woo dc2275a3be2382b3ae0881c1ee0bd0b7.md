# Call w/ Ji-woo

Attendees: Dana Whitfield
Created by: טל אדלר
Date: August 9, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Integration: commercial ERP with ~400 custom reorder rules
- Pilot scope: one store region
- supplier lead times matter
- Budget: pilot ~$300k, rollout maybe $1.3M/yr if it works