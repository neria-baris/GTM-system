# Kavala Markets

Attendees: Simone Carver
Created by: טל אדלר
Date: July 24, 2026
Last edited by: טל אדלר
Meeting type: Follow-up

# Agenda

- Intro Vendora
- Their pain points

# Notes

- ordering rules nobody fully understands - Jun Hao says this costs them real money
- Setup: forecasting module that is replaceable behind the ordering interface
- store-level daily ordering
- Keen - wants a deep dive with their engineers
- Next: send one-pager, book scoping w/ Jun Hao's team