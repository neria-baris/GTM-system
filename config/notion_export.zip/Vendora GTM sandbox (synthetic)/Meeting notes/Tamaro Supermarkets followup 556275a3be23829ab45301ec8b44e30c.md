# Tamaro Supermarkets followup

Attendees: Dana Whitfield
Created by: טל אדלר
Date: March 28, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Hard constraint: shelf-life limits on fresh lines are hard constraints
- Pilot scope: one store region
- promotions break the heuristics
- Budget: pilot ~€150k, rollout maybe €770k/yr if it works