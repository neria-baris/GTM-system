# Quorra <> Vendora

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: March 29, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: 12 months shipment history
- Pilot scope: 3-warehouse cluster
- customer-level fill-rate KPIs
- Budget: pilot ~€210k, rollout maybe €1M/yr if it works