# Westra Trading <> Vendora

Attendees: Simone Carver
Created by: טל אדלר
Date: August 18, 2026
Last edited by: טל אדלר

# Agenda

- Kickoff
- Data access
- Success criteria

# Notes

- Pilot signed: €135k, 10 weeks
- Scope: shadow-mode planning on 500 SKUs
- Success = inventory turns improvement in shadow mode, zero violations of 'fill rate never below SLA'