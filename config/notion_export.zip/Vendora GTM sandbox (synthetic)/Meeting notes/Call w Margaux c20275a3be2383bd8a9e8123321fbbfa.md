# Call w/ Margaux

Attendees: Dana Whitfield
Created by: טל אדלר
Date: August 19, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: POS sales history
- Pilot scope: one product family, shadow mode
- delivery schedule coupling with ordering