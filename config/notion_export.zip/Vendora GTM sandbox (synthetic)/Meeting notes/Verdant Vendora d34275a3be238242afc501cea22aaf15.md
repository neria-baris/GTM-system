# Verdant <> Vendora

Attendees: Simone Carver
Created by: טל אדלר
Date: December 7, 2025
Last edited by: טל אדלר

# Agenda

# Notes

- changeovers take too long - Margaux says this costs them real money
- Setup: MRP software + data lake
- forecast transfer across product lines
- Keen - wants the benchmark result on their data
- Next: send one-pager, book scoping w/ Margaux's team