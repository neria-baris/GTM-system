# Mosel Fracht

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: June 23, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Forecast model fit on historic data, held-out error within tolerance
- wk 8. next: interim results to their VP