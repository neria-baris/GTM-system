# Coldharbour <> Vendora

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: December 12, 2025
Last edited by: טל אדלר

# Agenda

# Notes

- Hard constraint: no stock shipped past its expiry window
- Pilot scope: one distribution centre
- seasonal vaccines with spiky demand