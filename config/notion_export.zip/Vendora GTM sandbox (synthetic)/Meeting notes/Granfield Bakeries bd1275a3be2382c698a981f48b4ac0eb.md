# Granfield Bakeries

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: February 21, 2026
Last edited by: טל אדלר

# Agenda

- Kickoff
- Data access
- Success criteria

# Notes

- Pilot signed: €75k, 10 weeks
- Scope: one production line
- Success = waste reduction in shadow mode, zero violations of 'never exceed cold-storage capacity'