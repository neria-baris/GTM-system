# Rhona <> Vendora

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: April 16, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: warehouse cost data
- Pilot scope: regional warehouses in one country
- safety stock vs cross-docking