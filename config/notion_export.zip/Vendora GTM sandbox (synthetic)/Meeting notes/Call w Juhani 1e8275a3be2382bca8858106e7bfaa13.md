# Call w/ Juhani

Attendees: Owen Marsh
Created by: טל אדלר
Date: May 6, 2026
Last edited by: טל אדלר
Meeting type: Pilot sync

# Agenda

- Kickoff
- Data access
- Success criteria

# Notes

- Pilot signed: €185k, 13 weeks
- Scope: shadow-mode planning on 500 SKUs
- Success = on-time-in-full improvement in shadow mode, zero violations of 'fill rate never below SLA'