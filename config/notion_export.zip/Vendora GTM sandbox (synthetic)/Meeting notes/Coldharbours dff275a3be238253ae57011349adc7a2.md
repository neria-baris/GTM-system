# Coldharbours

Attendees: Owen Marsh, Simone Carver
Created by: טל אדלר
Last edited by: טל אדלר
Meeting type: Pilot sync

# Agenda

# Notes

- (call on 13/05)
- Results: 14% fewer expiry write-offs, no constraint violations
- Steering committee: go to commercial
- ACV discussed €580k/yr