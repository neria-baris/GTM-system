# Verdant Creamery <> Vendora

Attendees: Simone Carver
Created by: טל אדלר
Date: January 12, 2026
Last edited by: טל אדלר
Meeting type: Scoping

# Agenda

# Notes

- Hard constraint: never exceed cold-storage capacity
- Pilot scope: one production line
- forecast transfer across product lines
- Budget: pilot ~€90k, rollout maybe €185k/yr if it works
- Verbal yes to paid pilot, SOW being drafted