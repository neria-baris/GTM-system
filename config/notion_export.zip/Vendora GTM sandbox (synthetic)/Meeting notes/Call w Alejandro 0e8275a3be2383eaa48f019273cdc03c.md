# Call w/ Alejandro

Attendees: Dana Whitfield
Created by: טל אדלר
Date: April 11, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Integration: in-house ERP + spreadsheet replenishment
- Pilot scope: one store region
- want to see the benchmark result extended to fresh categories