# Granfield Bakeries <> Vendora

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: March 23, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Blocked ~2 weeks on data export, unblocked now
- wk 4. next: interim results to their VP