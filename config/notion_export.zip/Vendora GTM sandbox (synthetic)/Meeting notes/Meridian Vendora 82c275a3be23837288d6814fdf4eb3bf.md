# Meridian <> Vendora

Attendees: Dana Whitfield
Created by: טל אדלר
Date: May 10, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Short call, distracted
- Chiara has gone quiet - may be changing role
- chase in 2 weeks