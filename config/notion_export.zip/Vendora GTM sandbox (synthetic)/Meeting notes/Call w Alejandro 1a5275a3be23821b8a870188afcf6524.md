# Call w/ Alejandro

Attendees: Dana Whitfield
Created by: טל אדלר
Date: May 30, 2026
Last edited by: טל אדלר
Meeting type: Pilot sync

# Agenda

# Notes

- Shadow policy: 3% fewer stock-outs
- wk 4. next: second scenario