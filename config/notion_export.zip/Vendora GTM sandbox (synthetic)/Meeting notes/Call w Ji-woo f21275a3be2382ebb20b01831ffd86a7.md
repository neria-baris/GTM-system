# Call w/ Ji-woo

Attendees: Dana Whitfield
Created by: טל אדלר
Date: August 23, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: 18 months store order history
- Pilot scope: bakery and deli
- supplier lead times matter