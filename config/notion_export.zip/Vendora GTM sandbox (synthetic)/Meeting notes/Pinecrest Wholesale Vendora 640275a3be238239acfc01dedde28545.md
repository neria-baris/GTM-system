# Pinecrest Wholesale <> Vendora

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: July 23, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: daily stock-level feeds
- Pilot scope: shadow-mode planning on 500 SKUs
- inventory per SKU per week
- Budget: pilot ~$175k, rollout maybe $800k/yr if it works