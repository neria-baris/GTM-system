# Westra Trading <> Vendora

Attendees: Simone Carver
Created by: טל אדלר
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- (call on 28/06)
- working-capital target for 2027 with no plan - Magdalena says this costs them real money
- Setup: new WMS rollout
- safety stock vs cross-docking
- Keen - wants a deep dive with their engineers
- Next: send one-pager, book scoping w/ Magdalena's team