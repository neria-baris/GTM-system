# Westra Trading

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: July 20, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Integration: two-vendor WMS + vendor planning suite
- Pilot scope: shadow-mode planning on 500 SKUs
- they want it in the WMS not as a separate tool
- Budget: pilot ~€135k, rollout maybe €730k/yr if it works