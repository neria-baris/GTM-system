# Tamaro <> Vendora

Attendees: Dana Whitfield
Created by: טל אדלר
Date: March 3, 2026
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- ordering rules nobody fully understands - Alejandro says this costs them real money
- Setup: commercial ERP with ~400 custom reorder rules
- supplier lead times matter
- Keen - wants the benchmark result on their data
- Next: send one-pager, book scoping w/ Alejandro's team