# Nordahl

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: June 5, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Shadow policy: 6% lower inventory holding
- wk 4. next: weekly review with ops