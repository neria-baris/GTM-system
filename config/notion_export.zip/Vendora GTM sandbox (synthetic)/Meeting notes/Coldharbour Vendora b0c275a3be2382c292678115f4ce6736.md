# Coldharbour <> Vendora

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: April 7, 2026
Last edited by: טל אדלר
Meeting type: Pilot sync

# Agenda

# Notes

- Forecast model fit on historic data, held-out error within tolerance
- wk 12. next: second scenario