# Lucerna

Attendees: Simone Carver
Created by: טל אדלר
Date: June 27, 2026
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- auto-replenishment switched off because planners don't trust it - Brooke says this costs them real money
- Setup: home-grown scripts on stock reports
- multi-warehouse allocation conflicts
- Polite, not urgent. 'Interesting research'
- Next: send materials, ping in a few weeks