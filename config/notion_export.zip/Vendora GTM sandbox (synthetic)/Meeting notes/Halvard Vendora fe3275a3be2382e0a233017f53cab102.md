# Halvard <> Vendora

Attendees: Dana Whitfield
Created by: טל אדלר
Date: July 26, 2026
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- fresh produce stock-outs every weekend - Ji-woo says this costs them real money
- Setup: commercial ERP with ~400 custom reorder rules
- want to see the benchmark result extended to fresh categories
- Keen - wants to see the guardrail design
- Next: send one-pager, book scoping w/ Ji-woo's team