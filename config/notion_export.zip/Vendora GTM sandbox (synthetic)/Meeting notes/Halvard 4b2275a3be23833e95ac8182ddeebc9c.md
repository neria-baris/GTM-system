# Halvard

Attendees: Dana Whitfield
Created by: טל אדלר
Date: September 10, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Hard constraint: shelf-life limits on fresh lines are hard constraints
- Pilot scope: dairy category
- delivery schedule coupling with ordering
- Budget: pilot ~$300k, rollout maybe $1.3M/yr if it works
- Verbal yes to paid pilot, SOW being drafted