# Call w/ Chiara

Attendees: Dana Whitfield
Created by: טל אדלר
Date: April 19, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- reorder points hand-tuned per store - Chiara says this costs them real money
- Setup: in-house ERP + spreadsheet replenishment
- promotions break the heuristics
- Keen - wants a deep dive with their engineers
- Next: send one-pager, book scoping w/ Chiara's team