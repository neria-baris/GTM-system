# Verdant

Attendees: Dana Whitfield, Simone Carver
Created by: טל אדלר
Date: January 2, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Data: order data ~4,000 SKUs
- Pilot scope: one production line
- forecast transfer across product lines
- Budget: pilot ~€90k, rollout maybe €185k/yr if it works