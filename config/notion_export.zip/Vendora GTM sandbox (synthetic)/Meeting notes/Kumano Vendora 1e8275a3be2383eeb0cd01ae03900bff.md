# Kumano <> Vendora

Attendees: Simone Carver
Created by: טל אדלר
Date: April 4, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Lost - building in-house with their data science team
- Natsuki open to revisit next year