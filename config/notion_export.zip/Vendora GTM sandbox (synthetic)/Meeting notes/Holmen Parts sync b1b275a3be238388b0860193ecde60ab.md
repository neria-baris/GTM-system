# Holmen Parts sync

Attendees: Simone Carver
Created by: טל אדלר
Date: November 4, 2025
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- spare-parts shortages slow repairs - Lars says this costs them real money
- Setup: vendor EAM + in-house optimisation
- critical spares vs consumables
- Polite, not urgent. 'Interesting research'
- Next: send materials, ping in a few weeks