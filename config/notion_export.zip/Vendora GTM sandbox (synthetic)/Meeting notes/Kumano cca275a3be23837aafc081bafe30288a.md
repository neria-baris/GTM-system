# Kumano

Attendees: Simone Carver
Created by: טל אדלר
Date: March 9, 2026
Last edited by: טל אדלר

# Agenda

- Intro Vendora
- Their pain points

# Notes

- carrying costs up sharply YoY - Natsuki says this costs them real money
- Setup: new WMS rollout
- customer-level fill-rate KPIs
- Polite, not urgent. 'Interesting research'
- Next: send materials, ping in a few weeks