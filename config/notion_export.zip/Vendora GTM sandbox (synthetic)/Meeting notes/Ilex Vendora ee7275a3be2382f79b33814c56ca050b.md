# Ilex <> Vendora

Attendees: Dana Whitfield
Created by: טל אדלר
Date: August 3, 2026
Last edited by: טל אדלר
Meeting type: Scoping

# Agenda

# Notes

- Integration: commercial ERP with ~400 custom reorder rules
- Pilot scope: dairy category
- want to see the benchmark result extended to fresh categories
- Budget: pilot ~€230k, rollout maybe €1.1M/yr if it works