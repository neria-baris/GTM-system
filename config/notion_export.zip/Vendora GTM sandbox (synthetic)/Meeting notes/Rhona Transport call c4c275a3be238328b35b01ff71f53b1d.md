# Rhona Transport call

Attendees: Simone Carver
Created by: טל אדלר
Date: May 22, 2026
Last edited by: טל אדלר

# Agenda

- Kickoff
- Data access
- Success criteria

# Notes

- Pilot signed: €95k, 16 weeks
- Scope: 3-warehouse cluster
- Success = inventory turns improvement in shadow mode, zero violations of 'every transfer order reversible before dispatch'