# Mosel Fracht

Attendees: Owen Marsh, Simone Carver
Created by: טל אדלר
Date: August 25, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Results mixed (3%)
- Rollout budget not approved