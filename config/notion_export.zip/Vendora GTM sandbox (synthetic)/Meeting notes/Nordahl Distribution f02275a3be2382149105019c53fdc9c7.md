# Nordahl Distribution

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: March 29, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Hard constraint: fill rate never below SLA
- Pilot scope: 3-warehouse cluster
- customer-level fill-rate KPIs
- Budget: pilot ~€185k, rollout maybe €930k/yr if it works