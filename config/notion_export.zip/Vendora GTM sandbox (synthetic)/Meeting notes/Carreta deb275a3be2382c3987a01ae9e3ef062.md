# Carreta

Attendees: Owen Marsh
Created by: טל אדלר
Date: July 1, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Lost - couldn't get historic data
- Luca open to revisit next year