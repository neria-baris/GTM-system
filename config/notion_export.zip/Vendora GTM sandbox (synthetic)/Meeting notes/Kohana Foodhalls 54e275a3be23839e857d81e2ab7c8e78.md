# Kohana Foodhalls

Attendees: Simone Carver
Created by: טל אדלר
Date: March 8, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Lost - building in-house with their data science team
- Hideo open to revisit next year