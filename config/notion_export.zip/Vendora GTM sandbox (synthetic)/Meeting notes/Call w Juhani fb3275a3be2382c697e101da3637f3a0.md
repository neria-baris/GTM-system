# Call w/ Juhani

Attendees: Dana Whitfield, Owen Marsh
Created by: טל אדלר
Date: March 8, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- Guardrail flagged some proposed orders that would've broken a hard constraint - they liked that
- wk 8. next: weekly review with ops