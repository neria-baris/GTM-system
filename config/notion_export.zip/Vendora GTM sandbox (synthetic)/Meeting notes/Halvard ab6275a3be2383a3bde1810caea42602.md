# Halvard

Attendees: Dana Whitfield
Created by: טל אדלר
Date: August 20, 2026
Last edited by: טל אדלר

# Agenda

# Notes

- They want to extend to a second region if pilot works
- Ji-woo's number for full rollout ~€2.2M/yr